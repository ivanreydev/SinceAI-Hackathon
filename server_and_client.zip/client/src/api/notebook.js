// Backend adapter for the notebook's API (ingest.ipynb / ingest_fixed.ipynb, last cell).
// /nb/* is forwarded to it on http://127.0.0.1:8000: by the Vite proxy in dev (see
// vite.config.js), and by server/app.py in the built app.
//
// The notebook finds similar situations; what the UI shows about each one (summary,
// messages) is its raw text, GET /situations/{key}. This file turns both into the
// shapes in types.js.

const BASE = "/nb";

async function request(path, init) {
    const res = await fetch(`${BASE}${path}`, {
        ...init,
        headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    });
    if (!res.ok) {
        const body = await res.text().catch(() => "");
        const error = new Error(`${res.status} ${res.statusText}${body ? `: ${body}` : ""}`);
        error.status = res.status;
        throw error;
    }
    return res;
}

const situationId = (key) => `SIT-${String(key).padStart(3, "0")}`;

function keyOf(id) {
    const m = String(id).match(/^(?:SIT-)?0*(\d+)$/i);
    if (!m) throw new Error(`Unknown situation id ${id}`);
    return Number(m[1]);
}

const SOURCE_TYPES = ["teams", "email", "ticket"];

function pointer(source, key, seq) {
    return {
        store: "vector_index",
        catalog: "local",
        schema: "processing",
        table: "situations",
        key: `${source}:sit-${key}${seq ? `:seq-${seq}` : ""}`,
        sourceType: source,
    };
}

// ------------------------------------------------------------ details

const detailsCache = new Map(); // key -> Promise<details>; a situation's text never changes

/** The situation's raw text (<key>.txt): first line as summary, one message per line. */
function loadDetails(key) {
    if (!detailsCache.has(key)) {
        const promise = request(`/situations/${key}`)
            .then((res) => res.text())
            .then((text) => {
                const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
                return {
                    summary: lines[0]?.slice(0, 140),
                    messages: lines.map((line, i) => ({
                        seq: i + 1,
                        author: "Situation text",
                        time: "",
                        text: line,
                    })),
                };
            });
        promise.catch(() => detailsCache.delete(key)); // retry next time
        detailsCache.set(key, promise);
    }
    return detailsCache.get(key);
}

// What the last searches said about each situation, so the detail view can reuse it
const seen = new Map(); // key -> { timestamp, distance, relevance }

function sourceOf(details) {
    return SOURCE_TYPES.includes(details.source) ? details.source : "teams";
}

function solutionsOf(key, details, timestamp) {
    const source = sourceOf(details);
    const raw = (details.solutions ?? []).filter((s) => s && s.action);
    const ids = raw.map((_, i) => `SOL-${String(key).padStart(3, "0")}-${i + 1}`);
    const states = raw.map((s) =>
        ["valid", "superseded", "conflicting"].includes(s.status) ? s.status : "valid",
    );

    return raw.map((sol, i) => {
        const validFrom = sol.valid_from || timestamp;
        let supersededBy = null;
        let validTo = null;
        if (states[i] === "superseded") {
            const later = states.findIndex((st, j) => j > i && st === "valid");
            supersededBy = later >= 0 ? ids[later] : "later advice";
            validTo = (later >= 0 && raw[later].valid_from) || validFrom;
        }
        let conflictsWith = [];
        if (states[i] === "conflicting") {
            conflictsWith = ids.filter((_, j) => j !== i && states[j] === "conflicting");
            if (conflictsWith.length === 0) conflictsWith = ["other advice"];
        }
        return {
            id: ids[i],
            action: sol.action,
            author: sol.author || "Unknown",
            validFrom,
            validTo,
            supersededBy,
            conflictsWith,
            pointers: [pointer(source, key, Number.isInteger(sol.message) ? sol.message : null)],
        };
    });
}

function statusOf(solutions) {
    const states = solutions.map((s) =>
        s.supersededBy ? "superseded" : s.conflictsWith.length ? "conflicting" : "valid",
    );
    if (states.includes("conflicting")) return "conflicting";
    if (states.length && !states.includes("valid")) return "outdated";
    return "valid";
}

/** SituationDetail without the 0..1 scores (client.js adds those). */
function toDetail(key, details, known = {}) {
    const timestamp = details.timestamp || known.timestamp || "";
    const summary = details.summary || `Situation ${situationId(key)}`;
    const solutions = solutionsOf(key, details, timestamp);
    return {
        id: situationId(key),
        summary,
        categories: details.tags ?? [],
        entities: details.entities ?? [],
        distance: known.distance ?? 0,
        relevance: known.relevance,
        timestamp,
        status: statusOf(solutions),
        why: [],
        problems: [
            {
                id: `PRB-${String(key).padStart(3, "0")}`,
                symptoms: details.symptoms?.length ? details.symptoms : [summary],
                pointers: details.messages?.length ? [pointer(sourceOf(details), key, 1)] : [],
            },
        ],
        solutions,
    };
}

function mentions(details, entity) {
    const needle = entity.trim().toLowerCase();
    const haystack = [
        details.summary,
        ...(details.entities ?? []),
        ...(details.messages ?? []).map((m) => m.text),
    ]
        .join(" ")
        .toLowerCase();
    return haystack.includes(needle);
}

// ---------------------------------------------------------- endpoints

/** SearchRequest -> RawHit[] (best match first), like POST /api/situations/search. */
export async function searchSituations(req) {
    const limit = req.limit ?? 10;
    const filtering = Boolean(req.entity || req.at);
    const res = await request("/similar", {
        method: "POST",
        body: JSON.stringify({ text: req.description, k: Math.min(100, filtering ? limit * 3 : limit) }),
    });
    const { results } = await res.json();

    const atMs = req.at ? Date.parse(req.at) : null;
    const candidates = results.filter((r) => atMs === null || Date.parse(r.timestamp) <= atMs);
    const allDetails = await Promise.all(candidates.map((r) => loadDetails(r.key)));

    const hits = [];
    candidates.forEach((r, i) => {
        const details = allDetails[i];
        if (req.entity && !mentions(details, req.entity)) return;
        const known = { timestamp: r.timestamp, distance: r.distance, relevance: r.relevance };
        seen.set(r.key, known);
        const hit = toDetail(r.key, details, known);
        delete hit.problems; // a search hit is a RawHit: no problems/solutions
        delete hit.solutions;
        hits.push({ ...hit, why: req.entity ? [`entity: ${req.entity}`] : [] });
    });
    return hits.slice(0, limit);
}

/** Like GET /api/situations/{id}. */
export async function getSituation(id) {
    const key = keyOf(id);
    return toDetail(key, await loadDetails(key), seen.get(key));
}

/** Like GET /api/sources/{key}; keys come from the pointers built above. */
export async function getSource(sourceKey) {
    const m = String(sourceKey).match(/^(teams|email|ticket):sit-(\d+)(?::seq-(\d+))?$/);
    if (!m) throw new Error(`Unknown source ${sourceKey}`);
    const [, sourceType, keyText, seqText] = m;
    const key = Number(keyText);
    const highlight = seqText ? Number(seqText) : null;
    const details = await loadDetails(key);
    return {
        key: `${sourceType}:sit-${key}`,
        sourceType,
        title: details.summary || `Situation ${situationId(key)}`,
        capturedAt: details.timestamp || seen.get(key)?.timestamp || "",
        messages: (details.messages ?? []).map((msg, i) => {
            const seq = msg.seq ?? i + 1;
            return {
                seq,
                author: msg.author || "Unknown",
                time: msg.time || "",
                text: msg.text || "",
                highlighted: seq === highlight,
            };
        }),
    };
}

/** The notebook has no category list; nothing in the UI asks for one yet. */
export async function getCategories() {
    return [];
}

/** Ingest runs offline in the notebook setup. */
export async function ingest() {
    throw new Error(
        "Ingest isn't available from the UI: run processing/separation.py, then the notebook's vectorize cell.",
    );
}
