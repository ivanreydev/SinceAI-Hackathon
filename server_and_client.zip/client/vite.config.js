import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // The notebook's API (ingest.ipynb / ingest_fixed.ipynb, last cell): /nb/similar -> :8000/similar
      '/nb': {
        target: 'http://127.0.0.1:8000',
        rewrite: (path) => path.replace(/^\/nb/, ''),
      },
      // server/app.py (run on 8080)
      '/api': 'http://127.0.0.1:8080',
    },
  },
  // The backend serves this folder as static files
  build: { outDir: 'build' },
})
