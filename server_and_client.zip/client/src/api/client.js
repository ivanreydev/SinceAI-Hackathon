// One function per backend endpoint. The backend is the notebook's API (see notebook.js);
// the Vite proxy forwards /nb to it.
/** @typedef {import("./types").SearchRequest} SearchRequest */
import * as mocks from "./mocks/handlers";
import * as notebook from "./notebook";
// Set VITE_USE_MOCKS=true in client/.env.development to work without the backend.
const USE_MOCKS = import.meta.env.VITE_USE_MOCKS?.toLowerCase() === "true";
const backend = USE_MOCKS
    ? {
          searchSituations: mocks.mockSearch,
          getSituation: mocks.mockGetSituation,
          getSource: mocks.mockGetSource,
          getCategories: mocks.mockGetCategories,
          ingest: mocks.mockIngest,
      }
    : notebook;
// The backend sends raw values (distance, timestamp). The UI turns them into 0..1 here.
// The notebook also sends its own 0..1 `relevance`; when present it is used as is, so the
// meters match the notebook's ranking.
const DISTANCE_SCALE = 1000; // distance at which relevancy drops to ~37%
const RECENCY_HALF_LIFE_DAYS = 180; // a situation this old has recency 0.5
const RELEVANCY_WEIGHT = 0.7; // score = 0.7 * relevancy + 0.3 * recency
const DAY_MS = 86_400_000;
function toHit(raw, at) {
    const now = at ? Date.parse(at) : Date.now();
    const ageDays = Math.max(0, (now - Date.parse(raw.timestamp)) / DAY_MS);
    const relevancy = Number.isFinite(raw.relevance)
        ? raw.relevance
        : Math.exp(-Math.max(0, raw.distance) / DISTANCE_SCALE);
    const recency = Number.isFinite(ageDays) ? 0.5 ** (ageDays / RECENCY_HALF_LIFE_DAYS) : 0;
    const score = RELEVANCY_WEIGHT * relevancy + (1 - RELEVANCY_WEIGHT) * recency;
    return { ...raw, relevancy, recency, score };
}
// Mocks return the same raw shape as the backend, so both go through toHit().
export async function searchSituations(req) {
    const list = await backend.searchSituations(req);
    return { results: list.map((raw) => toHit(raw, req.at)) };
}
export async function getSituation(id) {
    return toHit(await backend.getSituation(id));
}
export function getSource(key) {
    return backend.getSource(key);
}
export function getCategories() {
    return backend.getCategories();
}
export async function ingest(req) {
    const res = await backend.ingest(req);
    return { ...res, situations: res.situations.map((raw) => toHit(raw)) };
}
