"""FastAPI app: serves the /api routes and the built React app from client/build.

Run from server/: uvicorn app:app --port 8080  (port 8000 is the notebook API).
"""

import os
import urllib.error
import urllib.request
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.concurrency import run_in_threadpool

BUILD_DIR = Path(__file__).resolve().parent.parent / "client" / "build"

# The notebook's situation-search API (last cell of ingest.ipynb / ingest_fixed.ipynb).
NOTEBOOK_API = os.environ.get("NOTEBOOK_API", "http://127.0.0.1:8000").rstrip("/")

app = FastAPI(title="Hackathon 2026")


# --- API ---------------------------------------------------------------------
# Shapes are defined in client/src/api/types.js. Scores go out on a 0..1000 scale.


@app.get("/api/health")
def health():
    return {"status": "ok"}


def _not_implemented():
    raise HTTPException(status_code=501, detail="Not implemented yet")


@app.post("/api/situations/search")
def search_situations(body: dict):
    _not_implemented()


@app.get("/api/situations/{situation_id}")
def get_situation(situation_id: str):
    _not_implemented()


@app.get("/api/sources/{key}")
def get_source(key: str):
    _not_implemented()


@app.get("/api/categories")
def get_categories():
    _not_implemented()


@app.post("/api/ingest")
def ingest(body: dict):
    _not_implemented()


# --- Notebook API pass-through ---------------------------------------------------
# The client calls /nb/* (client/src/api/notebook.js). In dev, Vite forwards it to the
# notebook; in the built app it comes here and is forwarded the same way.


@app.api_route("/nb/{path:path}", methods=["GET", "POST"], include_in_schema=False)
async def notebook_api(path: str, request: Request):
    url = f"{NOTEBOOK_API}/{path}"
    if request.url.query:
        url += f"?{request.url.query}"
    body = await request.body()
    headers = {}
    if "content-type" in request.headers:
        headers["Content-Type"] = request.headers["content-type"]
    upstream = urllib.request.Request(url, data=body or None, headers=headers, method=request.method)

    def send():
        try:
            with urllib.request.urlopen(upstream, timeout=600) as res:  # searches call Gemini: can be slow
                return res.status, res.read(), res.headers.get("Content-Type")
        except urllib.error.HTTPError as e:  # pass the notebook's own errors through
            return e.code, e.read(), e.headers.get("Content-Type")

    try:
        status, content, content_type = await run_in_threadpool(send)
    except urllib.error.URLError as e:
        raise HTTPException(status_code=502, detail=f"Notebook API not reachable at {NOTEBOOK_API} ({e.reason})")
    return Response(content=content, status_code=status, media_type=content_type)


# --- Frontend ----------------------------------------------------------------

if (BUILD_DIR / "assets").is_dir():
    app.mount("/assets", StaticFiles(directory=BUILD_DIR / "assets"), name="assets")


@app.get("/{path:path}", include_in_schema=False)
def frontend(path: str):
    if path.startswith(("api/", "nb/")):
        raise HTTPException(status_code=404)
    # Serve real files (favicon.svg, icons.svg, ...) and fall back to index.html.
    file = (BUILD_DIR / path).resolve()
    if path and file.is_file() and BUILD_DIR in file.parents:
        return FileResponse(file)
    index = BUILD_DIR / "index.html"
    if not index.is_file():
        raise HTTPException(status_code=503, detail="Frontend not built. Run client/build.sh")
    return FileResponse(index)
